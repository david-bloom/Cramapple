# Cramapple More help reviewer demo

Private Sites project: appgprj_6acce98383c081919ff8366486967cbc.

## Experience

Choose calculus (average rate of change) or chemistry (molarity), answer the MCQ and optionally enter
reasoning, check the answer, then open More help. Direct entry into More help is also supported.
The question stays visible beside a generated repair. Focused follow-up buttons regenerate help
for the requested concept. The reviewer rates usefulness and submits comments; the answer,
explanation and feedback are retained for the owner at /feedback.

MCQs are checked against the two fixed verified keys. This demo does not call the Production
Cramapple grading engines, change mastery, or read Production student histories.
Reference formulas are based on the verified reference-pack concepts; recall sentences are
demo-authored explanations and are not represented as published hook-bank entries.

## Runtime

Vinext / Cloudflare Worker with D1 DB binding. AI_GATEWAY_API_KEY is configured through Sites as a
server-only secret; it never appears in client code or committed configuration. The live catalog
was checked before selecting anthropic/claude-haiku-5.5. The fixed model is limited to 1,000 output
tokens, bounded inputs, 100 requests across the Site per rolling 24 hours, and 30 per visitor.
The API uses same-origin POSTs and authenticated visitor identity. Student input is treated as
untrusted evidence. Structured output, length, and reference IDs are validated before display.

Feedback writes are explicit, visitor-owned and idempotent by help request. Collected feedback
is readable only by the owner; user IDs and feedback are not sent to the model. The model receives
only the current question, bounded answer/reasoning, curated references and current-help context.
Application deployment applies the schema-only Drizzle migration.

## Editing and checks

Edit demo-source.html and run node scripts/prepare-demo.mjs to refresh app/demo-content.ts.
Server-owned question content lives in app/lessons.ts.

Checks completed:
- TypeScript --noEmit passes.
- Sites build passes.
- Local D1 migration applies.
- Browser: answer entry/check, question highlighting, double-pane entry and error recovery render.
- Local feedback integration: save/update, malformed rating, cross-origin write, anonymous write,
  and non-owner feedback read all behave correctly.

## Current blocker

Live generation returned HTTP 402, error type insufficient_funds, from the existing AI Gateway.
No generated response has been claimed as successful. The owner has been asked whether to wait
for a top-up or send a scripted interface demo first. Do not invite reviewers to a broken live flow.
The previous scripted publication stays live until the new experience is ready.

Recipients supplied by the owner: Orly obloom27@solebury.org, Micah mbloom29@solebury.org.
Private viewer grants and the feedback request email should be sent only after the live path works,
or after the owner explicitly selects the scripted alternative.

import { env } from "cloudflare:workers";
export function json(value:unknown,status=200){return Response.json(value,{status,headers:{"Cache-Control":"private, no-store"}});}
export function database(){if(!env.DB)throw new Error("Database connection unavailable.");return env.DB;}
export function sameOrigin(request:Request){const origin=request.headers.get("origin");return !!origin&&origin===new URL(request.url).origin;}
export function ownerEmail(){return "dbloom01@gmail.com";}

import { z } from "zod";
import { lessons } from "../../lessons";
import { getChatGPTUser } from "../../chatgpt-auth";
import { json,sameOrigin } from "../../api-utils";
export async function POST(request:Request){
 if(!sameOrigin(request))return json({error:"This request must come from the demo."},403);
 if(!await getChatGPTUser())return json({error:"Please sign in."},401);
 const parsed=z.object({subject:z.enum(["calc","chem"]),choice:z.number().int().min(0).max(3)}).safeParse(await request.json().catch(()=>null));
 if(!parsed.success)return json({error:"Choose an answer first."},400);
 const correct=parsed.data.choice===lessons[parsed.data.subject].correct;
 return json({correct,correct_letter:"B"});
}

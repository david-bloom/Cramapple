import { z } from "zod";
import { getChatGPTUser } from "../../chatgpt-auth";
import { database,json,ownerEmail,sameOrigin } from "../../api-utils";
const schema=z.object({requestId:z.string().uuid(),name:z.string().trim().min(1).max(80),rating:z.number().int().min(1).max(5),comment:z.string().trim().max(2000)});
export async function POST(request:Request){
 if(!sameOrigin(request))return json({error:"This request must come from the demo."},403);
 const user=await getChatGPTUser();if(!user)return json({error:"Please sign in to send feedback."},401);
 if(Number(request.headers.get("content-length")||0)>7000)return json({error:"Please keep feedback brief."},413);
 const parsed=schema.safeParse(await request.json().catch(()=>null));if(!parsed.success)return json({error:"Enter your name, choose a rating, and keep comments under 2,000 characters."},400);
 const db=database(),input=parsed.data;
 const help=await db.prepare("SELECT id FROM help_requests WHERE id=? AND user_id=? AND response_json IS NOT NULL").bind(input.requestId,user.userId).first();
 if(!help)return json({error:"Please try More help before submitting feedback."},400);
 await db.prepare("INSERT INTO feedback (id,request_id,user_id,reviewer_name,rating,comment,created_at) VALUES (?,?,?,?,?,?,?) ON CONFLICT(request_id) DO UPDATE SET reviewer_name=excluded.reviewer_name,rating=excluded.rating,comment=excluded.comment").bind(crypto.randomUUID(),input.requestId,user.userId,input.name,input.rating,input.comment,new Date().toISOString()).run();
 return json({saved:true});
}
export async function GET(){
 const user=await getChatGPTUser();if(!user||user.email.toLowerCase()!==ownerEmail())return json({error:"Owner access required."},403);
 const rows=await database().prepare("SELECT f.reviewer_name,f.rating,f.comment,f.created_at,h.subject,h.answer,h.reasoning,h.response_json FROM feedback f JOIN help_requests h ON h.id=f.request_id ORDER BY f.created_at DESC LIMIT 100").all();
 return json({feedback:rows.results});
}

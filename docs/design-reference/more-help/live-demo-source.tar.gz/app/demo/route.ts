import { getChatGPTUser } from "../chatgpt-auth";
import { demoHTML } from "../demo-content";
import { lessons } from "../lessons";
import { ownerEmail } from "../api-utils";
export async function GET(){
 const user=await getChatGPTUser();
 if(!user)return new Response("Please sign in to open the demo.",{status:401});
 const meta=Object.fromEntries(Object.entries(lessons).map(([id,d])=>[id,{title:d.title,topic:d.topic,question:d.question,choices:d.choices,highlights:d.highlights,focuses:d.focuses}]));
 const safe=(x:unknown)=>JSON.stringify(x).replace(/</g,"\\u003c");
 const html=demoHTML.replace("__LESSON_DATA__",safe(meta)).replace("__USER_NAME__",safe(user.fullName||"")).replace("__IS_OWNER__",String(user.email.toLowerCase()===ownerEmail()));
 return new Response(html,{headers:{"Content-Type":"text/html; charset=utf-8","Cache-Control":"private, no-store"}});
}

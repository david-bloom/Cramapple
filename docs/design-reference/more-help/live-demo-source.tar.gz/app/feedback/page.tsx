import { requireChatGPTUser } from "../chatgpt-auth";
import { database,ownerEmail } from "../api-utils";
export const dynamic="force-dynamic";
export default async function Feedback(){
 const user=await requireChatGPTUser("/feedback");
 if(user.email.toLowerCase()!==ownerEmail())return <main style={{padding:30}}>This feedback page is for the demo owner.</main>;
 const result=await database().prepare("SELECT f.reviewer_name,f.rating,f.comment,f.created_at,h.subject,h.answer,h.reasoning,h.response_json FROM feedback f JOIN help_requests h ON h.id=f.request_id ORDER BY f.created_at DESC LIMIT 100").all<{reviewer_name:string;rating:number;comment:string;created_at:string;subject:string;answer:string;reasoning:string;response_json:string}>();
 return <main style={{maxWidth:900,margin:"auto",padding:30,fontFamily:"Arial,sans-serif"}}><a href="/">Back to More help</a><h1>More help feedback</h1><p>{result.results.length} responses received.</p>{result.results.map((r,i)=><article key={i} style={{border:"1px solid #ddd",padding:20,marginBottom:20}}><h2>{r.reviewer_name} · {r.subject} · {r.rating}/5</h2><p>{r.comment||"No written comments."}</p><details><summary>Answer and generated help</summary><p>Answer: {r.answer}</p><p>Reasoning: {r.reasoning||"Not supplied"}</p><p>{JSON.parse(r.response_json).explanation}</p></details><small>{r.created_at}</small></article>)}</main>;
}

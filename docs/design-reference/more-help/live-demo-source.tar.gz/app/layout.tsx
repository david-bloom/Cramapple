import type { Metadata } from "next";
import "./globals.css";
export const metadata:Metadata={title:"Cramapple | More help",description:"Answer a question, try More help, and tell us what helped."};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body style={{margin:0}}>{children}</body></html>;}

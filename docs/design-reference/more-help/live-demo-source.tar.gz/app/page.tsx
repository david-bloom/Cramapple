import { requireChatGPTUser } from "./chatgpt-auth";
export const dynamic="force-dynamic";
export default async function Home(){
 await requireChatGPTUser("/");
 return <iframe src="/demo" title="Cramapple More help reviewer demo" style={{width:"100%",height:"100dvh",border:0,display:"block"}}/>;
}

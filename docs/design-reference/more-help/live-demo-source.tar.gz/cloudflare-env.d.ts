declare namespace Cloudflare { interface Env { DB?:D1Database; BUCKET?:R2Bucket; AI_GATEWAY_API_KEY?:string; } }

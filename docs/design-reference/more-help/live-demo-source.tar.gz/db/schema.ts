import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
export const helpRequests = sqliteTable("help_requests", {
 id:text("id").primaryKey(),userId:text("user_id").notNull(),subject:text("subject").notNull(),
 answer:text("answer").notNull(),reasoning:text("reasoning").notNull(),focus:text("focus").notNull(),
 responseJson:text("response_json"),createdAt:text("created_at").notNull(),
});
export const feedback=sqliteTable("feedback", {
 id:text("id").primaryKey(),requestId:text("request_id").notNull().unique(),userId:text("user_id").notNull(),
 reviewerName:text("reviewer_name").notNull(),rating:integer("rating").notNull(),
 comment:text("comment").notNull(),createdAt:text("created_at").notNull(),
});

CREATE TABLE `feedback` (
	`id` text PRIMARY KEY NOT NULL,
	`request_id` text NOT NULL,
	`user_id` text NOT NULL,
	`reviewer_name` text NOT NULL,
	`rating` integer NOT NULL,
	`comment` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `feedback_request_id_unique` ON `feedback` (`request_id`);--> statement-breakpoint
CREATE TABLE `help_requests` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`subject` text NOT NULL,
	`answer` text NOT NULL,
	`reasoning` text NOT NULL,
	`focus` text NOT NULL,
	`response_json` text,
	`created_at` text NOT NULL
);

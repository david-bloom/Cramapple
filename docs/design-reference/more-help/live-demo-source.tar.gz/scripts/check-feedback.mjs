// Local integration check; fixture data is never deployed.
const origin="http://127.0.0.1:5173";
const login=await fetch(origin+"/signin-with-chatgpt?return_to=/",{redirect:"manual"});
const cookie=login.headers.get("set-cookie")?.split(";")[0];
if(!cookie)throw new Error("Local sign-in cookie missing");
const input={requestId:"11111111-1111-4111-8111-111111111111",name:"Local QA",rating:4,comment:"Fixture validation only."};
async function post(body,headers={}) {
 return fetch(origin+"/api/feedback",{method:"POST",headers:{"Content-Type":"application/json",Origin:origin,Cookie:cookie,...headers},body:JSON.stringify(body)});
}
let response=await post(input);if(response.status!==200||!(await response.json()).saved)throw new Error("Feedback save failed");
response=await post({...input,rating:5});if(response.status!==200||!(await response.json()).saved)throw new Error("Idempotent update failed");
response=await post({...input,rating:8});if(response.status!==400)throw new Error("Invalid rating accepted");
response=await post(input,{Origin:"https://other.example"});if(response.status!==403)throw new Error("Cross-origin write accepted");
response=await post(input,{Cookie:""});if(response.status!==401)throw new Error("Unauthenticated write accepted");
response=await fetch(origin+"/api/feedback",{headers:{Cookie:cookie}});if(response.status!==403)throw new Error("Non-owner read accepted");
console.log("Feedback save/update, input validation, Origin checks, authentication and owner-only reads pass.");

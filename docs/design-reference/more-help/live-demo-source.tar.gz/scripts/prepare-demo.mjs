import {readFileSync,writeFileSync} from "node:fs";
writeFileSync(new URL("../app/demo-content.ts",import.meta.url),"export const demoHTML = "+JSON.stringify(readFileSync(new URL("../demo-source.html",import.meta.url),"utf8"))+";\n");
